import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'flight-booking',
    templateUrl: './flight-booking.component.html'
})
export class FlightBookingComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
    
}