
export abstract class LoggerConfig {
    enableDebug: boolean;
}

